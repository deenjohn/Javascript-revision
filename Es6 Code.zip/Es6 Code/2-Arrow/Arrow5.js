var invoice = {
  number: 123,
  process: function() {
    console.log(this);
  }
};
invoice.process();
