"use strict";
var getPrice = () => 5.99;
console.log(typeof getPrice);
