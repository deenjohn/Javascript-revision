function Prefixer(prefix) {
    this.prefix = prefix;
}
Prefixer.prototype.prefixArray = function (arr) { // (A)
    //'use strict';
    console.log(this);
    return arr.map(function (x) { // (B)
        // Doesn’t work: why ?
        console.log(this);
        return this.prefix + x; // (C)
    });
};

var pre = new Prefixer('Hi ');
pre.prefixArray(['Joe', 'Alex'])