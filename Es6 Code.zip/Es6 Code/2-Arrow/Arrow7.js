var invoice = {
  number: 123,
  process: function() {
   
    return () => console.log(this.number);
  }
};
var newInvoice = {
  number: 456
};
invoice.process().bind(newInvoice)();

