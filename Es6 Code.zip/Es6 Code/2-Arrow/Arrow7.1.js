var invoice = {
  number: 123,
  process: function() {
    console.log(this);
    return () => console.log(this.number);
  }
};
var newInvoice = {
  number: 456
};
invoice.process().bind(newInvoice)();

