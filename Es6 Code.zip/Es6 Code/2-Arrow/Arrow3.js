"use strict";
var getPrice = count => count * 4.0;
console.log(getPrice(2));
