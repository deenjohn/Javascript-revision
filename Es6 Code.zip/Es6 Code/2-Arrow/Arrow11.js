function add(x, y) {
    return x + y;
}
const plus1 = add.bind(undefined, 1);


const plus1 = y => add(1, y);