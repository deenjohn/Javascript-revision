(() => 1);  // function returning a number value


(() => 'Hello'); // function returning a string value

(() => ()=>1); // function returning a function






//blocks

(() => {
         1
        }) ;  

(() => {
         'Hello'
        })