
var number = 12;

var invoice = {
  number: 123,
  process: function() {
    return () => console.log(number);
  }
};
invoice.process()();
