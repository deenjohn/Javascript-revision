function Prefixer(prefix) {
  this.prefix = prefix;
}
Prefixer.prototype.prefixArray = function(arr) {
  // (A)
  //"use strict";
  var that = this ;
  return arr.map(function(x) {
    // (B)
    // Doesn’t work:
    return that.prefix + x; // (C)
  },this);
};

var pre = new Prefixer("Hi ");

console.log(pre.prefixArray(["Joe", "Alex"]));
