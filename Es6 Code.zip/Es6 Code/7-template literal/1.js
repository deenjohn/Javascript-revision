"use strict";
let invoiceNum = "1350";
console.log(`Invoice Number: ${invoiceNum}`);

let invoiceNum = "1350";
console.log(`Invoice Number: \${invoiceNum}`);
