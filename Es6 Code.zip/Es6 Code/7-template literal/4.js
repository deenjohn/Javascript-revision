"use strict";
function showMessage(message) {
  let invoiceNum = "99";
  console.log(message);
}
let invoiceNum = "1350";
showMessage(`Invoice Number: ${invoiceNum}`);
