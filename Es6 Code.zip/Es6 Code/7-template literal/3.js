"use strict";
let invoiceNum = "1350";
console.log(`Invoice Number: ${"INV-" + invoiceNum}`);
