"use strict";
let message = `A
B
C`;
console.log(message);
