"use strict";
function processInvoice(segments) {
  console.log(segments);
}
processInvoice`template`;
