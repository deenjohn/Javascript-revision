var prices = [12, 20, 18];

var maxPrice = Math.max(prices);
console.log(maxPrice);

var maxPrice = Math.max(...prices);
console.log(maxPrice);
