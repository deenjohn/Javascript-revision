"use strict";
var showCategories = function(productId, ...categories) {
  console.log(categories);
};
showCategories(123, "search", "advertising");
