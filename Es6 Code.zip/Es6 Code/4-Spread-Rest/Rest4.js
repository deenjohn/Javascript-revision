"use strict";
var showCategories = new Function("...categories", "return categories;");
console.log(showCategories("search", "advertising"));
