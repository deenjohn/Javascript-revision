"use strict";
var codeArray = ["A", ..."BCD", "E"];
console.log(codeArray);
