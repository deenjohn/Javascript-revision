"use strict";

var showCategories = function(productId, ...categories) {
  console.log(arguments.length);
};
console.log(showCategories.length);
showCategories();

var showCategories = function(productId, ...categories) {
  console.log(arguments.length);
};
showCategories(123, "search", "advertising");
