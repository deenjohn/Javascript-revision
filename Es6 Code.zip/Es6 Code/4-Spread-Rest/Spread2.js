"use strict";
var newPriceArray = Array(...[, ,]);
console.log(newPriceArray);

