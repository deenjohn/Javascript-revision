var maxCode = Math.max(..."43210");
console.log(maxCode);
