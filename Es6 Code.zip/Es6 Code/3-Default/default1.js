"use strict";
var getTotal = function(price, tax = price * 0.07) {
  console.log(price + tax);
};
getTotal(5.0);
