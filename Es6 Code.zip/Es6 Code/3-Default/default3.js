"use strict";
var generateBaseTax = () => 0.07;
var getTotal = function(price, tax = price * generateBaseTax()) {
  console.log(price + tax);
};
getTotal(5.0);
