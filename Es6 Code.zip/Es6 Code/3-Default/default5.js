"use strict";
var getTotal = function(price = adjustment, adjustment = 1.0) {
  console.log(price + adjustment);
};
getTotal();
