var baseTax = 0.07;
var getTotal = function(price, tax = price * baseTax) {
  console.log(price + tax);
};
getTotal(5.0);
