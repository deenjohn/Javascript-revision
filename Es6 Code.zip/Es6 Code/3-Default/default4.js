"use strict";
var getTotal = function(price, tax = 0.07) {
  console.log(arguments.length);
};
getTotal(5.0);
