"use strict";
var categories = ["hardware", "software", "vaporware"];
for (var item of categories) {
  console.log(item);
}
