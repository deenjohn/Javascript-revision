"use strict";
var codes = "ABCDF";
var count = 0;
for (var code of codes) {
  count++;
}
console.log(count);
