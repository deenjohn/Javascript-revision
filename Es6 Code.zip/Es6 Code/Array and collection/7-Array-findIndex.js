let salaries = [600, 700, 800];
let result = salaries.findIndex(function(value, index, array) {
  return value == this;
}, 700);
console.log(result);
