let amounts = [800, 810, 820];
let salaries = Array.from(amounts, v => v + 100);
console.log(salaries);
