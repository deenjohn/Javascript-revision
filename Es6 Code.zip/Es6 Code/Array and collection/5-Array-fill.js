let salaries = [600, 700, 800];
salaries.fill(900);
console.log(salaries);
