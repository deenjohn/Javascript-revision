let amounts = [810, 820, 830];
let salaries = Array.from(amounts, v => v + this.adjustment, {
  adjustment: 50
});
console.log(salaries);
