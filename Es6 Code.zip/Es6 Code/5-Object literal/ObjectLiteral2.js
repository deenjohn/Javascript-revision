"use strict";
var price = 5.99,
  quantity = 10;
var productView = {
  price,
  quantity,
  calculateValue() {
    return this.price * this.quantity;
  }
};
console.log(productView.calculateValue());
