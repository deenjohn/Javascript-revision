"use strict";
var field = "dynamicField";
var price = 5.99;
var productView = {
  [field]: price
};
console.log(productView);
