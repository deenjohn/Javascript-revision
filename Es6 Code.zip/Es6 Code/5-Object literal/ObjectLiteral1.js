"use strict";
var price = 5.99,
  quantity = 30;
var productView = {
  price,
  quantity
};
console.log(productView);
