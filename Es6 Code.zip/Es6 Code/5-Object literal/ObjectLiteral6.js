"use strict";
var ident = "productId";
var productView = {
  get [ident]() {
    return true;
  },
  set [ident](value) {}
};
console.log(productView.productId);
