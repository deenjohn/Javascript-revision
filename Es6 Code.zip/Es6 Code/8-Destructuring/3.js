let salary = ["32000", "50000", "75000"];
let [low, , high] = salary;
console.log(high);
