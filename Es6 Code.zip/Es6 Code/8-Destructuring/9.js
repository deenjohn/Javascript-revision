"use strict";
let salary = {
  low: "32000",
  average: "50000",
  high: "75000"
};
let { low, average, high } = salary;
console.log(high);
