"use strict";
let salary = ["32000", "50000", ["88000", "99000"]];
let [low, average, [actualLow, actualHigh]] = salary;
console.log(actualLow);
