"use strict";
let [high, low] = null;
console.log(`high: ${high} low: ${low}`);
