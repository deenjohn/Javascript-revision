"use strict";
try {
  throw [123, "message"];
} catch ([invoiceNum, errorMessage]) {
  console.log(`${invoiceNum} ${errorMessage}`);
}
