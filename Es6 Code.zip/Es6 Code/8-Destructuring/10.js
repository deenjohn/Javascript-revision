"use strict";
let salary = {
  low: "32000",
  average: "50000",
  high: "75000"
};
let { low: newLow, average: newAverage, high: newHigh } = salary;
console.log(newHigh);
