function reviewSalary([low, average], high = "88000") {
  console.log(average);
}
reviewSalary(["32000", "50000"]);
