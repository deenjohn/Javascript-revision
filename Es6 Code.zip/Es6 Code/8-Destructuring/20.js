let nums = {
  high: 1000,
  low: 20,
  average: 400
};
let high, low, average;
({ high, low } = { average } = nums);
console.log(`${high} ${low} ${average}`);
