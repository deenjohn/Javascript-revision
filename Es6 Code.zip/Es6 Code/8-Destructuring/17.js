"use strict";
for (let [a, b] of [[5, 10]]) {
  console.log(`${a} ${b}`);
}
