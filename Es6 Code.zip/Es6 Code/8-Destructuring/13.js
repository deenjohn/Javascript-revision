"use strict";
let [high, low] = [,];
console.log(`high: ${high} low: ${low}`);
