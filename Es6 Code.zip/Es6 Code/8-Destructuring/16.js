"use strict";
let [high, low] = [500, 200];
console.log(`high: ${high} low: ${low}`);
