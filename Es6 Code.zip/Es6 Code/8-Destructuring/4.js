"use strict";
let salary = ["32000", "50000", "75000"];
let [low, ...remaining] = salary;
console.log(remaining);
