"use strict";
try {
  let [high, low] = undefined;
} catch (e) {
  console.log(e.name);
}
