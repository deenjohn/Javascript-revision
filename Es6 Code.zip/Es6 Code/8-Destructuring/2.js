"use strict";
let salary = ["32000", "50000"];
let [low, average, high] = salary;
console.log(high);
