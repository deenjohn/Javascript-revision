import { showProject, updateFunction } from "module1.js";
showProject();
updateFunction();
showProject();
