import { projectId as id, projectName } from "module1.js";
console.log(`${projectName} has id: ${projectId}`);
