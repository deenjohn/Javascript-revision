import { project, showProject } from "module1.js";
project.projectId = 8000;
showProject();
console.log(project.projectId);
