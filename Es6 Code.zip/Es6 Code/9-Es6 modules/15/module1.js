export let project = { projectId: 99 };
export function showProject() {
  console.log(project.projectId);
}
