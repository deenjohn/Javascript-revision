console.log("in module1");

export let projectId = 99;
