import { projectId } from "module1.js";
console.log(projectId);
