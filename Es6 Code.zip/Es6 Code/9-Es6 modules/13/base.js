import * as values from "module1.js";
console.log(values);
