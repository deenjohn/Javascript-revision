import { project } from "module1.js";
project.projectId = 8000;
console.log(project.projectId);
