import { default as myProjectName } from "module1.js";
console.log(myProjectName);
