console.log("starting in base");
import { projectId } from "module1.js";
console.log("ending in base");
