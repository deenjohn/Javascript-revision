export let projectId = 99;
console.log("in module1");
