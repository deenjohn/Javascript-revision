import someValue from "module1.js";
console.log(someValue);
