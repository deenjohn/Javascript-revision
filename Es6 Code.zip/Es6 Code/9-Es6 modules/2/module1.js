export let projectId = 99;
export let projectName = "BuildIt";
