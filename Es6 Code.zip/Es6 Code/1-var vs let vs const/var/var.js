'use strict';
console.log(productId);
var productId = 12;

