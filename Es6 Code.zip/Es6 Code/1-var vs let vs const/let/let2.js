let productId = 12;
{
  let productId = 2000;
}
console.log(productId);

var c = 2 ;
{
 var c = 2000;
}

console.log(c)