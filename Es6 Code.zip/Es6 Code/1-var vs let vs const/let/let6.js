"use strict";
let productId = 42;
for (let productId = 0; productId < 10; productId++) {}
console.log(productId);
