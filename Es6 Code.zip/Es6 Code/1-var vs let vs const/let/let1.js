'use strict';
console.log(productId);
let  productId = 12;

