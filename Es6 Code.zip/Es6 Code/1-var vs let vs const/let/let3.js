{
  let productId = 2000;
}
console.log(productId);
