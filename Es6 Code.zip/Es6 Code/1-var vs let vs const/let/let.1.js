function foo(x,y){

    if(x>y){
         var tmp = x; //hoisted
         x =y;
         y = tmp;
    }
    for(var i = 0;i<10;i++){

    }

     try{
      let z = bar(x*2)
     }catch(err){
       //..
     }


}