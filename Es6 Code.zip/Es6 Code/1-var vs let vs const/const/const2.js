"use strict";


const MARKUP_PCT = 100;
if (MARKUP_PCT > 0) {
   const MARKUP_PCT = 10;
}
console.log(MARKUP_PCT);
